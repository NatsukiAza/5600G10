---ENUNCIADO:Entrega 5 Base de datos lineamientos generales
---11/11/2025
---COMISION:5600
---GRUPO10
---BASE DE DATOS APLICADA
---INTEGRANTES:
---Brizzolara Ojeda Adriel Maximo de Jes�s, 43877825
---Azarola Santino, 45219619
---Tupia Caypo Catherine, 44596223
---Mu�oz Gimenez Facundo Ezequiel, 46346378
---Aranibar Machado Rocio, 45919583
---Vega Kevin, 45809150

if DB_ID('COM5600G10') is NOT NULL
	DROP database COM5600G10;
GO

create database COM5600G10;
GO
USE COM5600G10;

GO
